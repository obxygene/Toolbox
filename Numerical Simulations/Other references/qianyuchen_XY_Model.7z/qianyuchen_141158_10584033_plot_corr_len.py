import XY
import numpy as np
import matplotlib.pyplot as plt

def C(x,y,L):
    kx_val = np.linspace(-np.pi,np.pi,L+1)[1:]
    ky_val = np.linspace(-np.pi,np.pi,L+1)[1:]
    exponent = (x*kx_val)[:,np.newaxis]+(y*ky_val)
    denominator = 4-2*np.cos(kx_val)[:,np.newaxis]-2*np.cos(ky_val)
    denominator = XY.cutoff(denominator)
    ### cutoff the denominator
    return np.real(np.nansum((np.exp(1j*exponent)-1)/denominator)/L**2)


def Fitting(t,L): #fit the xi and eta at given tempreture and size L


    spin = XY.independent_spin(t,np.zeros((L,L)))
    spin = XY.sweep_fast(t,spin,Nsweep=100)
    Corr_measure = np.zeros_like(spin)
    Ntest = 10 #averages over 10 configurations.
    for _ in range(Ntest):
        spin = XY.independent_spin(t,spin)
        for i in range(L):
            for j in range(L):
                Corr_measure[i,j] += np.mean(np.cos(spin - np.roll(np.roll(spin,shift=i,axis= 1),shift=j,axis=0))) 
    Corr_measure/=10# consider the mean

    
    C_arr = np.zeros((L,L))
    for i in range(L):
        for j in range(L):
            C_arr[i,j] = C(i,j,L)


    X,Y = np.meshgrid(np.arange(L),np.arange(L))
    distance1 = np.sqrt(X**2+Y**2)
    distance2 = np.sqrt(X**2+(L-Y)**2)
    distance3 = np.sqrt((L-X)**2+(L-Y)**2)
    distance4 = np.sqrt((L-X)**2+Y**2)    


    def error(xi_inv,eta):
        Corr_theory = np.exp(-eta*C_arr)*(np.exp(-distance1*xi_inv)+np.exp(-distance2*xi_inv)+np.exp(-distance3*xi_inv)+np.exp(-distance4*xi_inv))/4
        return np.mean((Corr_measure - Corr_theory)**2)
    '''
    X = np.linspace(0,1,100)
    Y = np.linspace(-3,3,100)
    err = np.zeros((len(X),len(Y)))
    for x_ind,x in enumerate(Y):
        for y_ind,y in enumerate(X):
            err[x_ind,y_ind] = error(x,y)
    plt.contour(X,Y,np.log(err),levels=20)
    plt.colorbar()
    '''
    '''
    x = 0
    y = 0.
    dx = 10**(-7)
    dy = 10**(-7)
    a = 0.05
    while True: #gradient decent
        Dfx = (error(x+dx,y)-error(x,y))/dx
        Dfy = (error(x,y+dy)-error(x,y))/dx
        x = x + a*Dfx
        y = y + a*Dfy
        if Dfx**2+Dfy**2 < 10**(-6):
            break
        print(x,y)
        print(error(x,y))
        print('---------------')

    return x,y
    '''

print(Fitting(1.2,30))
plt.show()