import numpy as np
from numba import njit

def sweep(
        t:float, #tempreture
        spin, #takes in the spin array. 
        cluster : bool = True , # if true, then use Wolff update. else use Metropolis
        is_num_flip: bool = False, #if true, also returns the number of flips during the whole process
        Nsweep  : int  = 5
        )->np.ndarray:
    a,b = spin.shape
    if cluster:
        def Single_Wsweep(t:float, spin:np.ndarray, num_flip:bool): # defines single wolff cluster update
            phi = np.random.uniform(-np.pi,np.pi)
            # indicates if [x,y] is in cluster
            proj = np.cos(spin - phi)
            # calculate flip energy outside the loop

            x0 = np.random.randint(a)
            y0 = np.random.randint(b)
            r = np.random.uniform(size=np.size(spin)+1)
            r:np.ndarray = -(t/2)*np.log(r)

            in_cluster = build_cluster(proj,x0,y0,r)
            if not num_flip:
                return np.where(in_cluster,np.pi-spin+2*phi,spin)
            else:
                return np.where(in_cluster,np.pi-spin+2*phi,spin), np.sum(in_cluster)

        if not is_num_flip:
            for n in range(Nsweep):
                spin = Single_Wsweep(t,spin,False)
            return spin
        else:
            num_flip = 0
            for n in range(Nsweep):
                spin ,flip = Single_Wsweep(t,spin,True)
                num_flip+=flip
            return spin,num_flip

    else:
        num = a*b*Nsweep
        
        @njit
        def Sigle_Msweep(t,spin,px,py,r,ang,num = num,a = a,b = b):
            ################
            def nnEnergy(spin,x,y,angle):
                return (np.cos(spin[(x+1)%a,y]-angle)+np.cos(spin[(x-1)%a,y]-angle)+np.cos(spin[x,(y+1)%b]-angle)+np.cos(spin[x,(y-1)%b]-angle))
            ###############
            for n in range(num):
                x = px[n]
                y = py[n]
                dE = nnEnergy(spin,x,y,ang[n])-nnEnergy(spin,x,y,spin[x,y])
                if np.exp(dE/t) > r[n]:
                    spin[x,y] = ang[n]
            return spin

        if not is_num_flip:
            px =np.random.randint(a,size=num) 
            py = np.random.randint(b,size=num)
            r = np.random.uniform(0,1,size=num)
            ang =np.random.uniform(2*np.pi,size=num)
            return Sigle_Msweep(t,spin,px,py,r,ang)
        else:
            px =np.random.randint(a,size=num) 
            py = np.random.randint(b,size=num)
            r = np.random.uniform(0,1,size=num)
            ang =np.random.uniform(2*np.pi,size=num)
            return Sigle_Msweep(t,spin,px,py,r,ang) , num

@njit() #Core function
def build_cluster(proj:np.ndarray,x0:np.int64,y0:np.int64,r:np.ndarray)->np.ndarray:
    stack:list = [(x0,y0)]
    n:int = 0
    a,b=np.shape(proj)

    in_cluster:np.ndarray = np.zeros((a,b),dtype=np.bool_) 
    in_cluster[x0,y0] = True
    
    while stack: #while the stack is not empty,
        x,y = stack.pop()
        for nx,ny in [((x-1)%a,y),((x+1)%a,y),(x,(y-1)%b),(x,(y+1)%b)]: # nn site
            n +=1
            if not in_cluster[nx, ny]:
                if r[n] <  proj[x, y] * proj[nx,ny] : 
                    in_cluster[nx, ny] = True  
                    stack.append((nx, ny))
    return in_cluster

# use this to sweep faster
def sweep_fast(t:float,spin,Nsweep:int=50)->np.ndarray:
    a,b = spin.shape
    r = np.random.uniform(size= 4*np.size(spin))
    r:np.ndarray = -(t/2)*np.log(r) #reuse random number
    phi = np.random.uniform(-np.pi,np.pi,size=Nsweep)
    x = np.random.randint(a,size=Nsweep,dtype=np.int64)
    y = np.random.randint(b,size=Nsweep,dtype=np.int64)
    for n in range(Nsweep):
        proj = np.cos(spin - phi[n])
        in_cluster = build_cluster(proj,x[n],y[n],r)
        spin = np.where(in_cluster,(np.pi+2*phi[n])-spin,spin)
    return spin


def recursive_Single_Wsweep(t:float, spin:np.ndarray, num_flip:bool): # defines single wolff cluster update
            a,b = np.shape(spin)
    # we do not use this anymore.
    ####################
            phi = np.random.uniform(-np.pi,np.pi)
            in_cluster = np.zeros_like(spin,dtype=bool) 
            # indicates if [x,y] is in cluster

            proj = np.cos(spin - phi)
            # calculate flip energy outside the loop
            def build(x:int,y:int,r:np.ndarray,n:int):
                #returns if it is in cluster 
                for nx,ny in [((x-1)%a,y),((x+1)%a,y),(x,(y-1)%b),(x,(y+1)%b)]: # nn site
                    if in_cluster[nx,ny]: 
                        continue 
            #returns if one of nn is already in the cluster
                    if 1-np.exp(-2*proj[nx,ny]*proj[x,y]/t) > r[n]: 
                # the attempt of including [nx,ny] is accepted with probability 1-exp(-2/t (sx dot r)(sy dot r))
                        #n+=1
                        in_cluster[nx,ny] = True 
                # we add it into cluster 
                        n+=1
                        build(nx,ny,r,n+1) # and begin recursion

            x0 = np.random.randint(a)
            y0 = np.random.randint(b)

            in_cluster[x0,y0] = True
            r = np.random.uniform(size=3*np.size(spin))
            
            build(x0,y0,r,0)
            
            if not num_flip:
                return np.where(in_cluster,np.pi-spin+2*phi,spin)
            else:
                return np.where(in_cluster,np.pi-spin+2*phi,spin), np.sum(in_cluster)


#######################################################################


def acf(arr,axis=0): #calculate C_auto(tau) along some axis.
        arr = np.moveaxis(arr, axis, 0)
        total_sampling = np.size(arr, axis =0)
        t_max = total_sampling//2
        arr = arr - np.mean(arr, axis=axis, keepdims=True) #convert it into variance

        variance = np.mean(arr**2, axis=axis)  
        acfarr = []
        for n in range(t_max):
            acfarr.append( np.mean(arr[:total_sampling-n] * arr[n:],axis=axis) / variance)
        return np.array(acfarr)

def Magnetization(spin:np.ndarray,vecform:bool = True): #returns Magnetization
    # if vecfrom = True, then return component. Else return modular
    avg_x:float = np.average(np.cos(spin))
    avg_y:float = np.average(np.sin(spin))
    if not vecform:
        return np.sqrt(avg_x**2+avg_y**2)
    else:
        return [avg_x,avg_y]




def Energy(spin): #returns energy
    roll_x = np.roll(spin,1,axis=0)
    roll_y = np.roll(spin,1,axis=1)
    return -(np.average(np.cos(roll_x-spin))+np.average(np.cos(roll_y-spin)))


def Confidence_interval(arr,axis):
    std = np.std(arr,axis=axis)
    return 1.96*std/np.sqrt(np.size(arr,axis=axis)-1)


def rtime(L:int,Observable,cluster:bool,t:float=1,vecform = True):
    #returns relaxation time for Observable. 
    O = np.zeros(2000)
    for n in range(2000):
        spin,num_flip = sweep_fast(t,spin = np.zeros((L,L)),is_num_flip=True,cluster= cluster)
        O[n] = Observable(spin)
    
    if vecform:
        O_acf = np.sum(acf(O),axis=1)
    else:
        O_acf = acf(O)

    ind = 0
    for n in O_acf:
        ind+=1
        if n <0:
            break
    return np.sum(O_acf[:ind])*num_flip/2000


from statsmodels.tsa.stattools import acf as stacf
from scipy.stats import ks_2samp

def is_equilibrium(data: np.array, 
                     auto_corr_thresh: float = 0.1,
                     stat_threshold: float = 0.1,
                     p_threshold: float = 0.01,
                     min_data_points: int = 50) -> bool:
    # auto-corr analysis
    nlags = len(data)
    if nlags < 50:
        return False 
    #return false if it is too short
    #normally min-data-points = 500 
    #saves time since the program quits in the first part and do not do any time-consuming calculation
        
    acf = stacf(data, nlags=nlags, fft=False)
    acf_abs = np.abs(acf)
    lag_candidates = np.where(acf_abs <= auto_corr_thresh)[0]
    if len(lag_candidates) == 0:
        return False
    lag = lag_candidates[0]
    if lag < 1:
        return False
    # slicing
    sampled_data = data[::lag]
    
    # Make sure there is enough sample
    if len(sampled_data) < min_data_points:
        return False
    
    # separate into two parts
    split_idx = len(sampled_data) // 2
    part1 = sampled_data[:split_idx]
    part2 = sampled_data[split_idx:]
    
    # KS sampling
    stat, p_value = ks_2samp(part1, part2)
    
    # returns bool
    return p_value >= p_threshold or stat <= stat_threshold


def independent_spin(t,spin): #output a spin configuration that is independent of the input one
    M=[]
    for m in range(30000): #quit the loop and output the result if the loop is too long...
        spin = sweep_fast(t,spin,Nsweep=50) 
        M.append(Magnetization(spin,vecform=False))
        if is_equilibrium(np.array(M)): 
                        #print('Quit the loop successfully')
                        #print(m)
            break
    return spin

def cutoff(arr,epsilon = 10*(-8)):
    return np.where(arr<epsilon,epsilon,arr)


def vort(spin):
    v = np.zeros_like(spin,dtype=int)
    ds_x = spin - np.roll(spin,axis=0,shift=1)
    ds_y = spin - np.roll(spin,axis=1,shift=1)
    def normalize(spin):
        return (spin / (2*np.pi)+1/2)%1
    ds_x = normalize(ds_x)
    ds_y = normalize(ds_y)

    v = ds_x - np.roll(ds_x,axis= 1,shift= 1) - ds_y + np.roll(ds_y,axis= 0,shift=1)
    return np.round(v,2)
