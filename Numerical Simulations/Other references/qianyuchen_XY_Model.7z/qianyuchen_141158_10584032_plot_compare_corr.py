import XY
import numpy as np
import matplotlib.pyplot as plt

L = 50
spin = np.zeros((L,L),dtype=float)
spin = XY.sweep(0.65,spin,Nsweep=10000)
#generates the spin field
# first we initialize the C(r)
def C(x,y):
    kx_val = np.linspace(-np.pi,np.pi,L+1)[1:]
    ky_val = np.linspace(-np.pi,np.pi,L+1)[1:]
    exponent = (x*kx_val)[:,np.newaxis]+(y*ky_val)
    denominator = 4-2*np.cos(kx_val)[:,np.newaxis]-2*np.cos(ky_val)
    denominator = XY.cutoff(denominator)
    ### cutoff the denominator
    return np.real(np.nansum((np.exp(1j*exponent)-1)/denominator)/L**2)
    
C_arr = np.zeros((L,L),dtype=float)
for i in range(L):
    for j in range(L):
        C_arr[i,j] = C(i,j)    
    
Ntest = 20

avg_corr_arr = np.zeros((L,L),dtype=float)
for n in range(Ntest):
    corr_arr = np.zeros((L,L),dtype=float)
    spin = XY.sweep(0.65,spin,Nsweep=1000)
    for i in range(L):
        for j in range(L):
            corr_arr[i,j] = np.mean(np.cos(spin - 
            np.roll(
            np.roll(spin,shift=-i,axis=0),shift=-j,axis=1)))
    avg_corr_arr += corr_arr/Ntest

plt.figure(figsize=(12, 5))

plt.subplot(1, 3, 1)
plt.pcolor(C_arr, shading='auto', cmap='viridis',vmax = 0,vmin = -0.8)
plt.xlabel('x')
plt.ylabel('y')
plt.title('$\\theta$ Correlation $\\tilde{C}(r)$')

plt.subplot(1, 3, 2)
plt.pcolor(np.log(avg_corr_arr), shading='auto', cmap='viridis',vmax = 0,vmin = -0.8)
plt.colorbar()
plt.xlabel('x')
plt.yticks([])
plt.title('Log of Spin Correlation $\\ln G(r)$')


plt.subplot(1, 3, 3)

plt.contourf(np.log(avg_corr_arr)/C_arr, shading='nearest', cmap='viridis')
plt.colorbar(label='Estimated $2\\pi\\eta$')
plt.xlabel('x')
plt.yticks([])
plt.title("Plot of estimated $2\\pi\\eta$")
plt.tight_layout()

plt.show()