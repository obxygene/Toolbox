import XY
import numpy as np
import matplotlib.pyplot as plt

Nbin = 3000
fig, axs = plt.subplots(1,2)
spin = np.zeros((64,64),dtype=float)
size = 0
M = np.zeros((Nbin,2))
for n in range(Nbin):
        spin, s = XY.sweep(1,spin=spin,is_num_flip=True,Nsweep=1,cluster=True)
        M[n,:] = XY.Magnetization(spin)
        size +=s
print(M)
axs[0].plot(1+np.arange(Nbin//2,dtype=float)*(size/Nbin),np.sum(XY.acf(M), axis=1)/2,label ='Wolff',color = 'blue')
size = 0

Nbin = 300
M = np.zeros((Nbin,2))
for n in range(Nbin):
        spin, s = XY.sweep(1,spin=spin,is_num_flip=True,Nsweep=10,cluster=False)
        M[n,:] = XY.Magnetization(spin)
        size +=s
print(M)  
axs[0].plot(1+np.arange(Nbin//2,dtype=float)*(size/Nbin),np.sum(XY.acf(M), axis=1)/2,label ='Metropolis',color = 'red')
axs[0].legend()
axs[0].set_xscale('log')
axs[0].set_yscale('log')
axs[0].set_ylim([0.01,1])
axs[0].set_xlim([1,5*10**6])
axs[0].set_title('Typical autocorrelation function')
axs[0].set_ylabel('Autocorrelation of Magnetization')
axs[0].set_xlabel('Monte Carlo steps')
plt.show()
##############################



L = np.array([4,9,16,25,49,64,81,100,121,169,225,250])
sample = 15
M_rtime = np.zeros((len(L),sample),dtype=float)
W_rtime = np.zeros((len(L),sample),dtype=float)

for i,l in enumerate(L):
    for n in range(sample):
        M_rtime[i,n] = XY.rtime(l,XY.Magnetization,False)
        W_rtime[i,n] = XY.rtime(l,XY.Magnetization,True)



from scipy.stats import linregress
def fit_power_law(L, t_data):
    log_L = np.log(L)
    log_t_mean = np.log(np.mean(t_data, axis=1))  # take average then take log
    
    # linear fit
    res = linregress(log_L, log_t_mean)
    z = res.slope
    z_error = res.stderr  # standard error of slope
    
    # generate fitting line
    L_fit = np.linspace(L.min(), L.max(), 100)
    t_fit = np.exp(res.intercept) * L_fit**z
    
    return z, z_error, L_fit, t_fit

# fit the data
z_M, z_M_err, L_fit_M, t_fit_M = fit_power_law(L, M_rtime)
z_W, z_W_err, L_fit_W, t_fit_W = fit_power_law(L, W_rtime)

# Plot the results

# Metropolis
axs[1].errorbar(L, np.average(M_rtime, axis=1), yerr=XY.Confidence_interval(M_rtime),
            capsize=2, marker='o', label='Metropolis local update', color='red')

axs[1].plot(L_fit_M, t_fit_M, '--', color='darkred', 
        label=f'Metropolis Fit: $z = {z_M:.2f} \pm {z_M_err:.2f}$')

# Fit the data
axs[1].errorbar(L, np.average(W_rtime, axis=1)*(10**3), yerr=XY.Confidence_interval(W_rtime)*(10**3),
            capsize=2, marker='^', label='Wolff method $\\times 10^3$', color='blue')
#fitting line
axs[1].plot(L_fit_W, t_fit_W*(10**3), '--', color='navy', 
        label=f'Wolff Fit: $z = {z_W:.2f} \pm {z_W_err:.2f}$')

# log-log plot
axs[1].set_xscale('log')
axs[1].set_yscale('log')
axs[1].set_xlabel('System size $L$')
axs[1].set_ylabel('Estimated relaxation time')
axs[1].set_title('Dynamical scaling $t_{\mathrm{r}}\\sim L^z$')
axs[1].legend()
plt.tight_layout()
plt.show()